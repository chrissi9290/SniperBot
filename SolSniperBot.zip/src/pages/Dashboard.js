
import React from 'react';

const Dashboard = () => {
    return (
        <div className="p-6">
            <h1 className="text-3xl font-bold mb-4">SolSniper Bot Dashboard</h1>
            <div className="bg-white p-4 shadow rounded">
                <p>Hier kommen Portfolio-Tracking, Live-Preis, TP/SL-Einstellungen und der Sicherheits-Check-Button hin.</p>
            </div>
        </div>
    );
};

export default Dashboard;
